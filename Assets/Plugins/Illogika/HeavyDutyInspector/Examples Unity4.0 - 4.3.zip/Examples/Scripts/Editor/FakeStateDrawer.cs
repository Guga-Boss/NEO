//----------------------------------------------
//
//      Copyright © 2013 - 2014  Illogika
//----------------------------------------------
#if UNITY_4_0 || UNITY_4_1 || UNITY_4_2
using UnityEngine;
using UnityEditor;
using System.Collections;
using HeavyDutyInspector;

[CustomPropertyDrawer(typeof(FakeState))]
public class FakeStateDrawer : NamedMonoBehaviourDrawer {

	public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
	{
		type = typeof(FakeState);
		
		base.OnGUI(position, property, label);
	}
}
#endif
