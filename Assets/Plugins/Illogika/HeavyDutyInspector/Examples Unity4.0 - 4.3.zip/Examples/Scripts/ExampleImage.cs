//----------------------------------------------
//
//      Copyright © 2013 - 2014  Illogika
//----------------------------------------------
using UnityEngine;
using System.Collections;
using HeavyDutyInspector;

public class ExampleImage : MonoBehaviour {

	[Comment("Add images or logos in the Inspector", CommentType.Info, true)]
	public bool comment;

	// Your path can be relative to the Assets folder
	[Image("Illogika/HeavyDutyInspector/Examples/Textures/illogika-logo.png", Alignment.Center, true)]
	public bool hidden;
	
	// Or contain Assets/
	[Image("Assets/Illogika/HeavyDutyInspector/Examples/Textures/Resources/Textures/heavy_duty_logo.png", Alignment.Center, true)]
	public bool hidden2;
}
