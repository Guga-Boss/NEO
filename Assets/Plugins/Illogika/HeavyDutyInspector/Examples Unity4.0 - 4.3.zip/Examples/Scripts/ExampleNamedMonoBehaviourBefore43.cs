//----------------------------------------------
//
//      Copyright © 2013 - 2014  Illogika
//----------------------------------------------
using UnityEngine;
using System.Collections;
using HeavyDutyInspector;

public class ExampleNamedMonoBehaviourBefore43 : NamedMonoBehaviour {
#if UNITY_4_0 || UNITY_4_1 || UNITY_4_2
	[Comment("Set names on your scripts, and even a color the name will be displayed in", CommentType.Info, true)]
	public bool hidden1;

	[Comment("View your script references with more than just the GameObject's name and the script's type. Understand at a glance which script is referenced.", CommentType.Info, true)]
	public bool hidden2;

	[NamedMonoBehaviour(typeof(FakeState))]
	public FakeState attackState;

	[Comment("Extend the NamedMonoBehaviourDrawer class to allow any custom type extending NamedMonoBehaviour to be displayed with its custom name.", CommentType.Info, true)]
	public bool hidden3;

	public FakeState[] allStates;
#else
	[Comment("\n\nThis is the example for Unity 4.0 to 4.2. Please refer to the example for Unity 4.3 instead.\n\n", CommentType.Info, true)]
	public bool hidden1;
#endif
}
